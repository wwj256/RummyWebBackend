<?php
/* @var $this yii\web\View */
$this->title = '统计信息';
?>

<table class="table table-striped table-bordered"><thead>
    <tr><th>#</th><th>入账单数</th><th>入账金额</th></tr>
    </thead>
    <tbody>
        <tr data-key="6">
            <td>统计</td>
            <td><?php echo $statisticsData['count'] ?></td>
            <td><?php echo $statisticsData['amount'] ?></td>
        </tr>
        <?php foreach($statisticsDayData as $val){ ?>
            <tr data-key="<?=$val['time']?>">
                <td><?=$val['time']?></td>
                <td><?=$val['count']?></td>
                <td><?=$val['amount']?></td>
            </tr>
        <?php }?>
    </tbody>
</table>
