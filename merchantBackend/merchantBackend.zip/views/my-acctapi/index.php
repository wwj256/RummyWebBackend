<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\Acctapi */

$this->title = $model->uid;
$this->params['breadcrumbs'][] = ['label' => 'Acctapis', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="acctapi-view">

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'uid',
            'app_key',
            'shopname',
            'ustate',
            'createtime',
            'updatetime',
        ],
    ]) ?>

</div>
