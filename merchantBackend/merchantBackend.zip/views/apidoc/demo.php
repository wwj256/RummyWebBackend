<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/7/9
 * Time: 20:11
 */
$this->title = 'SDK/Demo下載';
?>
<div class="col-lg-9 g-mb-50">
    <!-- H5 -->
    <div class="g-brd-around g-brd-gray-light-v4 rounded g-px-30 g-pt-30 g-font-size-16">

        <p>如沒有找到相關語言的DEMO或者SDK，您暫時需要聯繫我們客服索取</p>
        <h5>Server</h5>
<!--        <a href="https://github.com/BitBlank/java-sdk" target="_blank">Java SDK</a>，-->
<!--        <a href="https://github.com/BitBlank/php-sdk" target="_blank">PHP SDK</a>，-->
<!--        <a href="https://github.com/BitBlank/golang-sdk" target="_blank">Go SDK</a>，<br>-->
        <a href="javascript:alert('制作中，稍后将上传')" >Java SDK</a>，
        <a href="javascript:alert('制作中，稍后将上传')" >PHP SDK</a>，
        <a href="javascript:alert('制作中，稍后将上传')" >Go SDK</a>，<br>
        <br>
        <br>
    </div>
    <!-- End H5 -->
</div>
