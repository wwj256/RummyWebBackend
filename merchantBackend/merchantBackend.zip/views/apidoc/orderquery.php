<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/7/9
 * Time: 20:10
 */
$this->title = '查詢接口（可選接口）';
?>
<!-- H5 -->
<div class="g-brd-around g-brd-gray-light-v4 rounded g-px-30 g-pt-30 g-font-size-16">
    <p>用來主動查詢訂單是否支付成功，一般情況只用發起支付+回檔接口即可。如果您伺服器中斷了一段時間，可以用這個接口，快速獲取中斷時期的訂單的支付狀態。注意：此接口不能頻繁查詢，每個訂單每分鐘只能查一次。不可替代回檔接口。</p>
    <p>接口URL：</p>
    <blockquote class="blockquote text-left g-bg-black g-color-white g-brd-left-none g-font-size-16 g-pa-10 g-mb-10">
        http://121.36.36.104:8080/ustd/public/index.php/api/order
    </blockquote>
    <p>傳參方式：<strong>GET</strong></p>
    <h2 data-anchor-id="yhyu" id="請求參數-2">請求參數</h2>
    <table data-anchor-id="21eb" class="table table-striped-white table-bordered">
        <thead>
        <tr>
            <th style="text-align:left;">參數</th>
            <th style="text-align:center;">必填</th>
            <th style="text-align:center;">類型</th>
            <th>描述</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td style="text-align:left;">order_id</td>
            <td style="text-align:center;">必填</td>
            <td style="text-align:center;">string(32)</td>
            <td>商戶訂單號，請保證訂單號的唯一性。</td>
        </tr>
        <tr>
            <td style="text-align:left;">time</td>
            <td style="text-align:center;">必填</td>
            <td style="text-align:center;">long</td>
            <td>發起支付時的伺服器時間，13位時間戳記，使用此參數是出於安全考慮，用來防禦請求重發攻擊</td>
        </tr>
        <tr>
            <td style="text-align:left;">app_key</td>
            <td style="text-align:center;">必填</td>
            <td style="text-align:center;">string(16)</td>
            <td>平臺生成的app key。在“商家後臺 - 商家資訊”中獲取</td>
        </tr>
        <tr>
            <td style="text-align:left;">sign</td>
            <td style="text-align:center;">必填</td>
            <td style="text-align:center;">string(32)</td>
            <td>簽名，<a href="/apidoc/sign">點此查看</a>簽名生成方法</td>

        </tr>
        </tbody>
    </table>
    <div class="md-section-divider"></div>
    <h2 data-anchor-id="0o4n" id="請求例子-2">請求例子</h2>
    <div class="md-section-divider"></div>
    <pre class="prettyprint linenums prettyprinted" data-anchor-id="zj1e" style=""><ol class="linenums"><li class="L0"><code><span class="pln">curl </span><span class="str">'http://121.36.36.104:8080/ustd/public/index.php/api/order?sign=e1f73a0b4f11eed4147a6ac761556e2b&amp;order_id=1&amp;app_key=4789e57f8629eb9e&amp;time=1234567890123'</span></code></li></ol></pre>
    <div class="md-section-divider"></div>
    <h2 data-anchor-id="b4ey" id="返回參數-2">返回參數</h2>
    <p>參數格式：：application/json</p>
    <table data-anchor-id="uok0" class="table table-striped-white table-bordered">
        <thead>
        <tr>
            <th style="text-align:left;">參數</th>
            <th style="text-align:center;">類型</th>
            <th>描述</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td style="text-align:left;">code</td>
            <td style="text-align:center;">int</td>
            <td> 狀態碼，200 代表獲取成功，其他狀態碼請對照<code>msg</code> 返回的資訊內容</td>
        </tr>
        <tr>
            <td style="text-align:left;">msg</td>
            <td style="text-align:center;">string</td>
            <td>提示資訊</td>
        </tr>
        <tr>
            <td style="text-align:left;">data</td>
            <td style="text-align:center;">object</td>
            <td>-</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.bapp_id</td>
            <td style="text-align:center;">string(32)</td>
            <td>平臺訂單號，此訂單號在 <code>XTPay</code>上唯一</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.order_id</td>
            <td style="text-align:center;">string(32)</td>
            <td>商戶訂單號，請保證訂單號的唯一性。</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.order_state</td>
            <td style="text-align:center;">int</td>
            <td>訂單狀態，<code>0：等待用戶支付</code> <code>1：支付成功</code> <code>2：訂單超時自動關閉</code></td>
        </tr>
        <tr>
            <td style="text-align:left;">data.body</td>
            <td style="text-align:center;">string(128)</td>
            <td>商品名稱，UTF8格式，用來顯示在支付頁上的商品名稱位置，還有您商戶後臺的訂單清單裡。</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.notify_url</td>
            <td style="text-align:center;">string</td>
            <td>回檔地址</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.order_ip</td>
            <td style="text-align:center;">string</td>
            <td>訂單發起端端ip</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.amount</td>
            <td style="text-align:center;">long</td>
            <td>訂單金額，單位字元（分）</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.amount_type</td>
            <td style="text-align:center;">string(16)</td>
            <td>訂單貨幣單位，輸入3個大寫字母，支持：USD-美元，CNY-人民幣，HKD-港幣，TWD-新臺幣，KRW-韓元，MOP-澳門元，JPY-日元，GBP-英鎊，SGD-新加坡元，EUR-歐元，RUB-盧布</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.amount_btc</td>
            <td style="text-align:center;">long</td>
            <td>比特幣金額，單位（聰）</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.pay_time</td>
            <td style="text-align:center;">long</td>
            <td>支付時間戳記（13 位元字元），如果未支付或者支付失敗，此值位 <code>0</code></td>
        </tr>
        <tr>
            <td style="text-align:left;">data.create_time</td>
            <td style="text-align:center;">long</td>
            <td>訂單創建時間戳記（13 位元字元）</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.order_type</td>
            <td style="text-align:center;">int</td>
            <td> 訂單類型，<code>1：掃碼支付</code> <code>2：H5支付</code> <code>3：APP原生支付</code></td>
        </tr>
        <tr>
            <td style="text-align:left;">data.app_key</td>
            <td style="text-align:center;">string</td>
            <td>平臺生成的 app key，16 位元字元</td>
        </tr>
        <tr>
            <td style="text-align:left;">data.extra</td>
            <td style="text-align:center;">string</td>
            <td>額外參數，最長 256 位元字元</td>
        </tr>


        </tbody>
    </table>

    <div class="md-section-divider"></div>
    <h2 data-anchor-id="ui54" id="返回例子-2">返回例子</h2>
    <div class="md-section-divider"></div>
    <pre class="prettyprint linenums prettyprinted" data-anchor-id="uxxy" style=""><ol class="linenums"><li class="L0"><code><span class="pun">{</span></code></li><li class="L1"><code><span class="pln">  </span><span class="str">"code"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">200</span><span class="pun">,</span></code></li><li class="L2"><code><span class="pln">  </span><span class="str">"msg"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"ok"</span><span class="pun">,</span></code></li><li class="L3"><code><span class="pln">  </span><span class="str">"data"</span><span class="pun">:</span><span class="pln"> </span><span class="pun">{</span></code></li><li class="L4"><code><span class="pln">    </span><span class="str">"bapp_id"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"20190618171802840b6a"</span><span class="pun">,</span></code></li><li class="L5"><code><span class="pln">    </span><span class="str">"order_id"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"1"</span><span class="pun">,</span></code></li><li class="L6"><code><span class="pln">    </span><span class="str">"order_state"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1</span><span class="pun">,</span></code></li><li class="L7"><code><span class="pln">    </span><span class="str">"body"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"goods_name"</span><span class="pun">,</span></code></li><li class="L8"><code><span class="pln">    </span><span class="str">"notify_url"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"https://***.com/notify/test"</span><span class="pun">,</span></code></li><li class="L9"><code><span class="pln">    </span><span class="str">"order_ip"</span><span class="pun">:</span><span class="pln"> </span><span class="str">""</span><span class="pun">,</span></code></li><li class="L0"><code><span class="pln">    </span><span class="str">"amount"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1</span><span class="pun">,</span></code></li><li class="L1"><code><span class="pln">    </span><span class="str">"amount_type"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"CNY"</span><span class="pun">,</span></code></li><li class="L2"><code><span class="pln">    </span><span class="str">"amount_btc"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">16</span><span class="pun">,</span></code></li><li class="L3"><code><span class="pln">    </span><span class="str">"pay_time"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1560859623468</span><span class="pun">,</span></code></li><li class="L4"><code><span class="pln">    </span><span class="str">"create_time"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1560849482796</span><span class="pun">,</span></code></li><li class="L5"><code><span class="pln">    </span><span class="str">"order_type"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">2</span><span class="pun">,</span></code></li><li class="L6"><code><span class="pln">    </span><span class="str">"app_key"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"4789e57f8629eb9e"</span><span class="pun">,</span></code></li><li class="L7"><code><span class="pln">    </span><span class="str">"extra"</span><span class="pun">:</span><span class="pln"> </span><span class="str">""</span></code></li><li class="L8"><code><span class="pln">  </span><span class="pun">}</span></code></li><li class="L9"><code><span class="pun">}</span></code></li></ol></pre>

</div>
