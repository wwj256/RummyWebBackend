<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/7/9
 * Time: 20:08
 */
$this->title = '發起支付接口（必用接口）';
?>
<div class="g-brd-around g-brd-gray-light-v4 rounded g-px-30 g-pt-30 g-font-size-16">

        <p>您有2種方式使用此接口：1.<mark class="g-bg-primary g-color-white">跳轉到我們官方的支付頁</mark>，我們支付頁支援PC和手機接口自我調整，PC上是掃碼支付，手機上是H5支付；2.<mark class="g-bg-primary g-color-white">自訂支付頁</mark>，在您自己的支付頁上，PC上展示付款二維碼，在手機上自動跳轉到二維碼對應位址，即可調起XTPay完成H5支付</p>

        <!--<h5 class="g-pt-40">1.跳转接口：跳转到我们官方支付页（支持PC,手机自适应界面）</h5>-->
        <p>接口URL：</p>
        <blockquote class="blockquote text-left g-bg-black g-color-white g-brd-left-none g-font-size-16 g-pa-10 g-mb-10">
            http://121.36.36.104:8080/ustd/public/index.php/api/pay
        </blockquote>
        <p>傳參方式：：<strong>POST</strong></p>
        <p>使用方法：您的伺服器端（server端）將參數以<mark class="g-bg-primary g-color-white">json格式</mark>post到我們指定接口。成功後，接口會返回一個json字串，您可以將使用者流覽器跳轉到返回的pay_url參數值的網址，讓用戶進入官方支付頁支付(相對簡單)；或者在自己自訂支付頁上(相對複雜)，直接將返回的qr_code參數值生成二維碼，展示在自己支付頁上；如果是手機端，可以直接將用戶跳轉到qr_code參數值的網址，會調起XTPay用戶端進行H5支付</p>

        <p>用戶付款成功後，我們會向您的notify_url發送這筆訂單支付成功的回檔通知</p>

        <!-- Warning Alert -->
        <div class="alert alert-warning" role="alert"><strong>安全注意：不要用用戶端來發送參數</strong> 用伺服器端發送參數的好處：可通過白名單方式控制發送參數的IP位址，不易被人CC攻擊</div>

        <!-- End Warning Alert -->
        <h2 data-anchor-id="11ms" id="請求參數">請求參數</h2>
        <p>以下所有參數，1個中文字、1個英文字母、1個標點符號、1個空格都只算1個字元</p>
        <table data-anchor-id="kflp" class="table table-striped-white table-bordered">
            <thead>
            <tr>
                <th style="text-align:left;">參數</th>
                <th style="text-align:center;">必填</th>
                <th style="text-align:center;">類型</th>
                <th>描述</th>
            </tr>
            </thead>
            <tbody>

            <tr>
                <td style="text-align:left;">order_id</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">string(32)</td>
                <td>商戶訂單號，最長 32 位元字元，請保證訂單號的唯一性</td>
            </tr>

            <tr>
                <td style="text-align:left;">amount</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">long</td>
                <td>訂單金額USDT，注意必須：<code>amount &gt; 0</code></td>
            </tr>
            <tr>
                <td style="text-align:left;">body</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">string(128)</td>
                <td>商品名稱，UTF8格式，用來顯示在支付頁上的商品名稱位置，還有您商戶後臺的訂單清單裡。</td>
            </tr>
            <tr>
                <td style="text-align:left;">return_url</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">string(256)</td>
                <td>支付成功後跳轉地址。注意：使用官方支付頁時必填；自訂支付頁則可不用填寫。用戶支付成功後，我們會將用戶流覽器自動跳轉到這個網址。注意此參數<mark class="g-bg-primary g-color-white">不要urlencode</mark>。例：https://www.aaa.com/pay_return</td>

            </tr>
            <tr>
                <td style="text-align:left;">notify_url</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">string(256)</td>
                <td>支付成功後回檔通知地址。使用者一旦支付成功，我們伺服器會非同步發送一個回檔通知到這個網址，具體參數<a href="/apidoc/notify">請看這裡</a>，如果回檔通知失敗，之後會按時間重試5次，分別是：訂單第一次回檔失敗後的5秒，10秒，30秒，1分鐘，5分鐘。重試5次後依然通知不成功，不會再自動重試，您之後可以用查詢接口完成判斷知否是否成功。注意此參數<mark class="g-bg-primary g-color-white">不要urlencode</mark>。例：http://www.aaa.com/pay_notify</td>

            </tr>
            <tr>
                <td style="text-align:left;">time</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">long</td>
                <td>發起支付時的伺服器時間，13位時間戳記，使用此參數是出於安全考慮，用來防禦請求重發攻擊</td>
            </tr>
            <tr>
                <td style="text-align:left;">app_key</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">string(16)</td>
                <td>平臺生成的app key。在“商家後臺 - 商家資訊”中獲取</td>
            </tr>
            <tr>
                <td style="text-align:left;">sign</td>
                <td style="text-align:center;">必填</td>
                <td style="text-align:center;">string(32)</td>
                <td>簽名，<a href="/apidoc/sign">點此查看</a>簽名生成方法</td>

            </tr>

            <tr>
                <td style="text-align:left;">order_ip</td>
                <td style="text-align:center;">可選</td>
                <td style="text-align:center;">string(45)</td>
                <td>訂單發起端ip(使用者的ip)，如：<code>114.114.114.114</code>，同時支持IPV6，方便您自己做風控用</td>
            </tr>
            <tr>
                <td style="text-align:left;">extra</td>
                <td style="text-align:center;">可選</td>
                <td style="text-align:center;">string(256)</td>
                <td>額外參數，支付成功會原樣返回，最長 256 位元字元</td>
            </tr>
            <tr>
                <td style="text-align:left;">lang</td>
                <td style="text-align:center;">可選</td>
                <td style="text-align:center;">string(16)</td>
                <td>支付页面语言，支持 zh_CN-简体中文；zh_TW-繁体中文；en-英文</td>
            </tr>

            </tbody>
        </table>

        <div class="md-section-divider"></div>
        <h2 data-anchor-id="9u25" id="請求例子">請求例子</h2>
        <div class="md-section-divider"></div>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="c9ql" style="">curl -X POST -H 'content-Type:application/json' -d '{"sign":"c99b0c73796ef1ead15a140e76542689","order_id":"1","amount":1,"time":1234567890123,"app_key":"4789e57f8629eb9e","body":"goods_name","notify_url":"https://***.com/notify/test","return_url":"https://baidu.com"}' http://121.36.36.104:8080/ustd/public/index.php/api/pay
      </pre>
        <div class="md-section-divider"></div>
        <h2 data-anchor-id="vqqg" id="返回參數">接口返回參數</h2>
        <p>參數格式：application/json</p>
        <table data-anchor-id="n213" class="table table-striped-white table-bordered">
            <thead>
            <tr>
                <th style="text-align:left;">參數</th>
                <th style="text-align:center;">類型</th>
                <th>描述</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td style="text-align:left;">code</td>
                <td style="text-align:center;">int</td>
                <td>狀態碼，200 代表獲取成功，其他狀態碼請對照<code>msg</code> 返回的資訊內容</td>
            </tr>
            <tr>
                <td style="text-align:left;">msg</td>
                <td style="text-align:center;">string</td>
                <td>提示資訊</td>
            </tr>
            <tr>
                <td style="text-align:left;">data.pay_url</td>
                <td style="text-align:center;">string</td>
                <td>自訂支付頁展示的資訊，PC上將此參數生成二維碼展示，手機流覽器可直接打開此地址即可調起XTPay完成支付</td>
            </tr>
            </tbody>
        </table>

        <h2 data-anchor-id="1r1d" id="返回例子">接口返回例子</h2>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="49hz" style=""><ol class="linenums"><li class="L0"><code><span class="pun">{</span></code></li><li class="L1"><code><span class="pln">  </span><span class="str">"code"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">200</span><span class="pun">,</span></code></li><li class="L2"><code><span class="pln">  </span><span class="str">"msg"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"ok"</span><span class="pun">,</span></code></li><li class="L3"><code><span class="pln">  </span><span class="str">"data"</span><span class="pun">:</span><span class="pln"> </span><span class="pun">{</span></code></li><li class="L5"><code><span class="pln">    </span><span class="str">"pay_url"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"http://121.36.36.104:8080/ustd/public/index.php/api/pay?oid=1"</span></code></li><li class="L6"><code><span class="pln">  </span><span class="pun">}</span></code></li><li class="L7"><code><span class="pun">}</span></code></li></ol></pre>

    </div>