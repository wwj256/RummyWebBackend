<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/7/9
 * Time: 20:10
 */
$this->title = '安全簽名方法（必用方法）';
?>
    <!-- H5 -->
    <div class="g-brd-around g-brd-gray-light-v4 rounded g-px-30 g-pt-30 g-font-size-16">
        <h2 data-anchor-id="7vxn" id="生成步驟">生成步驟</h2>
        <div class="md-section-divider"></div>
        <h3 data-anchor-id="cs90" id="第一步">第一步</h3>
        <p data-anchor-id="1zu8">設所有發送或者接收到的資料為<code>集合M</code>，將集合M內非空參數值的參數按照參數名ASCII碼從小到大排序（字典序）， 使用URL鍵值對的格式（即key1=value1&amp;key2=value2... ）拼接成字串<code>stringSignTemp</code></p>

        <p data-anchor-id="btwt">特別注意以下重要規則：</p>
        <ul data-anchor-id="jslg">
            <li>參數名ASCII碼從小到大排序（字典序）</li>
            <li>如果參數的值為null不參與簽名</li>
            <li>參數名區分大小寫</li>
            <li><code>集合M</code>中不能包含 <code>sign</code> 參數，若有，請去掉此參數再簽名</li>

        </ul>
        <div class="md-section-divider"></div>
        <h3 data-anchor-id="rn8h" id="第二步">第二步</h3>
        <p data-anchor-id="f3f6">在<code>stringSignTemp</code>最後拼接上<code>app_secret</code>得到<code> stringSignOrigin</code>字串</p>
        <div class="md-section-divider"></div>
        <h3 data-anchor-id="m7al" id="第三步">第三步</h3>
        <p data-anchor-id="ekvf">對<code>stringSignOrigin</code>進行MD5運算，再將得到的字串所有轉換為小寫，得到<code>sign</code> 值</p>

        <div class="md-section-divider"></div>
        <h2 data-anchor-id="e20d" id="舉例說明">舉例說明</h2>
        <p data-anchor-id="jlla">假如傳送的參數如下：</p>
        <div class="md-section-divider"></div>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="objk" style=""><ol class="linenums"><li class="L0"><code><span class="pln">app_key</span><span class="pun">:</span><span class="pln"> </span><span class="lit">00000000</span></code></li><li class="L0"><code><span class="pln">channel</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1</span></code></li><li class="L1"><code><span class="pln">platform</span><span class="pun">:</span><span class="pln"> </span><span class="lit">2</span></code></li><li class="L2"><code><span class="pln">money</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1</span></code></li><li class="L3"><code><span class="pln">client_ip</span><span class="pun">:</span><span class="pln"> </span><span class="lit">127.0</span><span class="pun">.</span><span class="lit">0.1</span></code></li><li class="L4"><code><span class="pln">subject</span><span class="pun">:</span><span class="pln"> my_subject</span></code></li></ol></pre>
        <blockquote data-anchor-id="95z0" class="white-blockquote">
            <p>假設app_secret為： <code>your_app_secret</code></p>
        </blockquote>
        <div class="md-section-divider"></div>
        <h3 data-anchor-id="7eus" id="第一步-1">第一步</h3>
        <p data-anchor-id="t5cc">得到 <code>stringSignTemp</code></p>

        <div class="md-section-divider"></div>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="6psj" style=""><ol class="linenums"><li class="L0"><code><span class="pln">stringSignTemp </span><span class="pun">=</span><span class="pln"> </span><span class="str">"app_key=00000000&amp;channel=1&amp;client_ip=127.0.0.1&amp;money=1&amp;platform=2&amp;subject=my_subject"</span></code></li></ol></pre>
        <div class="md-section-divider"></div>
        <h3 data-anchor-id="ff0u" id="第二步-1">第二步</h3>
        <p data-anchor-id="gevx">得到 <code>stringSignOrigin</code></p>

        <div class="md-section-divider"></div>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="2yr4" style=""><ol class="linenums"><li class="L0"><code><span class="pln">stringSignOrigin </span><span class="pun">=</span><span class="pln"> stringSignTemp </span><span class="pun">+</span><span class="pln"> </span><span class="str">"&amp;app_secret=your_app_secret"</span></code></li></ol></pre>
        <p data-anchor-id="hmy9">sign_p_9</p>

        <div class="md-section-divider"></div>
        <h3 data-anchor-id="8dti" id="第三步">第三步</h3>
        <p data-anchor-id="7s53">得到簽名</p>
        <div class="md-section-divider"></div>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="6dhq" style=""><ol class="linenums"><li class="L0"><code><span class="pln">signTemp </span><span class="pun">=</span><span class="pln"> md5</span><span class="pun">(</span><span class="pln">stringSignOrigin</span><span class="pun">)</span></code></li><li class="L1"><code><span class="pln">sign </span><span class="pun">=</span><span class="pln"> signTemp</span><span class="pun">.</span><span class="pln">toLowerCase</span><span class="pun">()</span></code></li></ol></pre>
        <p data-anchor-id="x4ma">即:</p>
        <div class="md-section-divider"></div>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="8ulo" style=""><ol class="linenums"><li class="L0"><code><span class="pln">md5</span><span class="pun">(</span><span class="str">"app_key=00000000&amp;channel=1&amp;client_ip=127.0.0.1&amp;money=1&amp;platform=2&amp;subject=my_subject&amp;app_secret=your_app_secret"</span><span class="pun">).</span><span class="pln">toLowerCase</span><span class="pun">()</span></code></li></ol></pre>
        <p data-anchor-id="4bss">得出的簽名如下</p>
        <div class="md-section-divider"></div>
        <pre class="prettyprint linenums prettyprinted" data-anchor-id="rtft" style=""><ol class="linenums"><li class="L0"><code><span class="lit">1af39b08e44a9016a359aebd42e97b07</span></code></li></ol></pre>

    </div>
