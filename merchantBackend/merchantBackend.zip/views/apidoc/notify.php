<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2020/7/9
 * Time: 20:10
 */
$this->title = '回檔通知接口（必用接口）';
?>
<div class="g-brd-around g-brd-gray-light-v4 rounded g-px-30 g-pt-30 g-font-size-16">
    <p>用戶支付成功後，我們會將成功訂單資訊以json格式傳到您的<mark class="g-bg-primary g-color-white">notify_url</mark>參數中對應的網址。notify_url是您發起支付時傳入的參數。</p>
    <p>收到支付結果後，請返回 <strong>SUCCESS</strong> 字符串給XTPay。</p>
    <p>如果回檔通知失敗，之後會按時間重試5次，分別是：訂單第一次回檔失敗後的5秒，10秒，30秒，1分鐘，5分鐘。重試5次後依然通知不成功，不會再自動重試，您之後可以用查詢接口完成判斷知否是否成功</p>
    <p>傳參方式：<strong>POST</strong></p>
    <p>參數格式：：application/json</p>
    <table data-anchor-id="vb67" class="table table-striped-white table-bordered">
        <thead>
        <tr>
            <th style="text-align:left;">參數</th>
            <th style="text-align:center;">類型</th>
            <th>描述</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td style="text-align:left;">bapp_id</td>
            <td style="text-align:center;">string(32)</td>
            <td>bapp平臺訂單號，此訂單號在XTPay上唯一</td>
        </tr>
        <tr>
            <td style="text-align:left;">order_id</td>
            <td style="text-align:center;">string(32)</td>
            <td>商戶訂單號，就是您發起訂單時傳入的order_id</td>
        </tr>
        <tr>
            <td style="text-align:left;">order_state</td>
            <td style="text-align:center;">int</td>
            <td>當前訂單狀態，有回檔的，必然支付成功，永遠=1</td>
        </tr>
        <tr>
            <td style="text-align:left;">order_type</td>
            <td style="text-align:center;">int</td>
            <td> 使用者付款方式，<code>1：掃碼支付</code> <code>2：H5支付</code><code>3：APP原生支付</code></td>
        </tr>
        <tr>
            <td style="text-align:left;">amount</td>
            <td style="text-align:center;">long</td>
            <td>訂單金額，單位（分），和發起訂單時金額一致，是未扣手續費之前的金額</td>
        </tr>
        <tr>
            <td style="text-align:left;">amount_type</td>
            <td style="text-align:center;">string(16)</td>
            <td>訂單貨幣單位，輸入3個大寫字母，支持：USD-美元，CNY-人民幣，HKD-港幣，TWD-新臺幣，KRW-韓元，MOP-澳門元，JPY-日元，GBP-英鎊，SGD-新加坡元，EUR-歐元，RUB-盧布</td>
        </tr>
        <tr>
            <td style="text-align:left;">amount_btc</td>
            <td style="text-align:center;">long</td>
            <td>比特幣金額，單位（聰）注釋：1BTC=100,000,000聰</td>
        </tr>
        <tr>
            <td style="text-align:left;">order_fee</td>
            <td style="text-align:center;">long</td>
            <td>商戶手續費,單位（分），幣種和傳入幣種相同</td>
        </tr>
        <tr>
            <td style="text-align:left;">order_fee_btc</td>
            <td style="text-align:center;">long</td>
            <td>商戶手續費，單位（聰）</td>
        </tr>
        <tr>
            <td style="text-align:left;">rate</td>
            <td style="text-align:center;">long</td>
            <td>交易時的比特幣匯率，單位（分/BTC）</td>
        </tr>


        <tr>
            <td style="text-align:left;">create_time</td>
            <td style="text-align:center;">long</td>
            <td>訂單創建時間戳記（13 位元字元）</td>
        </tr>
        <tr>
            <td style="text-align:left;">pay_time</td>
            <td style="text-align:center;">long</td>
            <td>支付時間戳記（13 位元字元）</td>
        </tr>
        <tr>
            <td style="text-align:left;">body</td>
            <td style="text-align:center;">string(128)</td>
            <td>商品名稱，UTF8格式，和您傳入的商品名稱一致</td>
        </tr>
        <tr>
            <td style="text-align:left;">extra</td>
            <td style="text-align:center;">string(256)</td>
            <td>額外參數，您發起支付帶入的參數，原樣返回</td>
        </tr>
        <tr>
            <td style="text-align:left;">order_ip</td>
            <td style="text-align:center;">string(45)</td>
            <td>IP參數，您發起支付帶入的參數，原樣返回</td>
        </tr>

        <tr>
            <td style="text-align:left;">time</td>
            <td style="text-align:center;">long</td>
            <td>伺服器時間，13位時間戳記，使用此參數是出於安全考慮，用來防禦請求重發攻擊</td>
        </tr>
        <tr>
            <td style="text-align:left;">app_key</td>
            <td style="text-align:center;">string(16)</td>
            <td>平臺生成的 app key，16 位元字元</td>
        </tr>
        <tr>
            <td style="text-align:left;">sign</td>
            <td style="text-align:center;">string(32)</td>
            <td>簽名，簽名方式和發起支付相同</td>
        </tr>


        </tbody>
    </table>
    <h2 data-anchor-id="1r1d" id="回调通知">回檔通知例子</h2>
    <pre class="prettyprint linenums prettyprinted" data-anchor-id="uxxy" style=""><ol class="linenums"><li class="L0"><code><span class="pln">  </span><span class="pun">{</span></code></li><li class="L1"><code><span class="pln">    </span><span class="str">"bapp_id"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"20190618171802840b6a"</span><span class="pun">,</span></code></li><li class="L2"><code><span class="pln">    </span><span class="str">"order_id"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"1"</span><span class="pun">,</span></code></li><li class="L3"><code><span class="pln">    </span><span class="str">"order_state"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1</span><span class="pun">,</span></code></li><li class="L4"><code><span class="pln">    </span><span class="str">"order_type"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">2</span><span class="pun">,</span></code></li><li class="L5"><code><span class="pln">    </span><span class="str">"amount"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1</span><span class="pun">,</span></code></li><li class="L6"><code><span class="pln">    </span><span class="str">"amount_type"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"CNY"</span><span class="pun">,</span></code></li><li class="L7"><code><span class="pln">    </span><span class="str">"amount_btc"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">16</span><span class="pun">,</span></code></li><li class="L8"><code><span class="pln">    </span><span class="str">"order_fee"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">0</span><span class="pun">,</span></code></li><li class="L9"><code><span class="pln">    </span><span class="str">"order_fee_btc"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">0</span><span class="pun">,</span></code></li><li class="L0"><code><span class="pln">    </span><span class="str">"rate"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">6432450</span><span class="pun">,</span></code></li><li class="L1"><code><span class="pln">    </span><span class="str">"create_time"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1560849482796</span><span class="pun">,</span></code></li><li class="L2"><code><span class="pln">    </span><span class="str">"pay_time"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1560859623468</span><span class="pun">,</span></code></li><li class="L3"><code><span class="pln">    </span><span class="str">"body"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"goods_name"</span><span class="pun">,</span></code></li><li class="L4"><code><span class="pln">    </span><span class="str">"extra"</span><span class="pun">:</span><span class="pln"> </span><span class="str">""</span><span class="pun">,</span></code></li><li class="L5"><code><span class="pln">    </span><span class="str">"order_ip"</span><span class="pun">:</span><span class="pln"> </span><span class="str">""</span><span class="pun">,</span></code></li><li class="L6"><code><span class="pln">    </span><span class="str">"time"</span><span class="pun">:</span><span class="pln"> </span><span class="lit">1561023663119</span><span class="pun">,</span></code></li><li class="L7"><code><span class="pln">    </span><span class="str">"app_key"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"4789e57f8629eb9e"</span><span class="pun">,</span></code></li><li class="L8"><code><span class="pln">    </span><span class="str">"sign"</span><span class="pun">:</span><span class="pln"> </span><span class="str">"d72e1c8d7efbac64cbc8ec5b76b00671"</span></code></li><li class="L9"><code><span class="pln">  </span><span class="pun">}</span></code></li></ol></pre>


</div>