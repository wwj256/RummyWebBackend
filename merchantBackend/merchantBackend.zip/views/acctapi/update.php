<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\Acctapi */

$this->title = '修改 Acctapi: ' . $model->uid;
$this->params['breadcrumbs'][] = ['label' => 'Acctapis', 'url' => ['index']];
$this->params['breadcrumbs'][] = ['label' => $model->uid, 'url' => ['view', 'id' => $model->uid]];
$this->params['breadcrumbs'][] = 'Update';
?>
<div class="acctapi-update">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
