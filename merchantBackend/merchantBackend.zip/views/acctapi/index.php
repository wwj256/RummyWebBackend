<?php
use mdm\admin\components\Helper;
use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $searchModel common\models\AcctapiSearchSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Acctapis';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="acctapi-index">

    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            'uid',
            'app_key',
            'shopname',
            [
                "attribute"=>'ustate',
                'format'=>'raw',
                'headerOptions' => ['width' => '7%'],
                'value'=>function($m){
                    return $m->ustate == 1 ? "已开启":"未开启";
                },
            ],
            'createtime',
            //'updatetime',

            [
                'class' => 'yii\grid\ActionColumn',
                'template' => Helper::filterActionColumn('{view} {update} {delete}'),
                'header' => '操作',
                'buttons' => [
                    'view' => function ($url, $model, $key) {
                        return Html::a('详情',$url, [
                            'class' => 'btn btn-default',
                        ]);
                    },
                    'delete' => function ($url, $model, $key) {
                        return Html::a('删除',$url, [
                            'class' => 'btn btn-danger',
                            'data-confirm'=>"您确定要删除此项吗？",
                            'data-method'=>"post",
                        ]);
                    },
                    'update' => function ($url, $model, $key) {
                        return Html::a('修改',$url, [
                            'class' => 'btn btn-primary',
                        ]);
                    },
                ],
            ],
        ],
    ]); ?>


</div>
