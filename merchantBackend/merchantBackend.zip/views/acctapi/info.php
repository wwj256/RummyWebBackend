<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model common\models\Acctapi */

$this->title = '我的信息';
$this->params['breadcrumbs'][] = $this->title;
\yii\web\YiiAsset::register($this);
?>
<div class="acctapi-view">
    <script>
        /**
         * 更新商户名称
         * @param x
         * @param gid
         */
        function updateName(value)
        {
            let colorTxt = document.getElementById('shopname');
            $.post("/acctapi/change-shop-name?id="+value+"&value="+colorTxt.value, function (data){alert(data)});
        }

    </script>
    <table id="w0" class="table table-striped table-bordered detail-view"><tbody>
        <tr><th> 商户ID</th><td><?php echo $model->uid ?></td></tr>
        <tr><th>AppKey</th><td><?php echo $model->app_key ?></td></tr>
        <tr><th>商户名称</th>
            <td>
                <div class="form-group field-acctapi-shopname">
                    <input type="text" id="shopname" class="form-control" name="Acctapi[shopname]" value="<?php echo $model->shopname ?>" maxlength="32">
                    <div class="help-block"></div>
                </div>
                <?= Html::button('修改',['id' => 'deliverynoTxt', 'class'=>"btn btn-success",'onclick'=>'
                        updateName('. $model->uid.')']) ?>
            </td></tr>
        <tr><th>状态</th><td><?php echo $model->ustate===1?"正常":"禁用" ?></td></tr>
    </table>

</div>
