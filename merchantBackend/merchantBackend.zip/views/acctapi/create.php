<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\Acctapi */

$this->title = '添加 Acctapi';
$this->params['breadcrumbs'][] = ['label' => 'Acctapis', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="acctapi-create">

    <?= $this->render('_form', [
        'model' => $model,
    ]) ?>

</div>
