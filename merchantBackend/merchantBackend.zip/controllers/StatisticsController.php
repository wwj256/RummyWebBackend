<?php

namespace merchantBackend\controllers;

use function MongoDB\BSON\toJSON;
use Yii;
use yii\helpers\Json;

class StatisticsController extends \yii\web\Controller
{
    public function actionIndex()
    {
        $uid = \Yii::$app->user->identity->getId();
        $result = [];
        //总数据
        $statisticsSql = "SELECT COUNT(oid) as count, SUM(amount) as amount FROM apiorder WHERE uid=$uid AND ostate = 0";
        $statisticsData = Yii::$app->db->createCommand($statisticsSql)
            ->queryOne();

        //每天的数据
        $statisticsSql = "SELECT DATE_FORMAT(createtime,'%Y-%m-%d') as time, COUNT(oid) as count, SUM(amount) as amount FROM apiorder WHERE uid=$uid AND ostate = 0 GROUP BY createtime ORDER BY createtime DESC;";
        $statisticsDayData = Yii::$app->db->createCommand($statisticsSql)
            ->query();

//        //今天的数据
//        $statisticsSql = "SELECT COUNT(oid) as count, SUM(amount) as amount FROM apiorder WHERE uid=$uid AND ostate = 1 AND TO_DAYS(createtime) = TO_DAYS(NOW())";
//        $statisticsData = Yii::$app->db->createCommand($statisticsSql)
//            ->query();
//        array_push($result,$statisticsData);
//
//        //昨天的数据
//        $statisticsSql = "SELECT COUNT(oid) as count, SUM(amount) as amount FROM apiorder WHERE uid=$uid AND ostate = 1 AND TO_DAYS(NOW()) - TO_DAYS(createtime) <=1";
//        $statisticsData = Yii::$app->db->createCommand($statisticsSql)
//            ->query();
//        array_push($result,$statisticsData);
//
//        //近三天的
//        $statisticsSql = "SELECT * FROM apiorder WHERE uid=$uid AND ostate = 1 AND DATE_SUB(CURDATE(),INTERVAL 3 DAY) <= DATE(createtime)";
//        $statisticsData = Yii::$app->db->createCommand($statisticsSql)
//            ->query();
//        array_push($result,$statisticsData);
//
//        //近七天的
//        $statisticsSql = "SELECT * FROM apiorder WHERE uid=$uid AND ostate = 1 AND DATE_SUB(CURDATE(),INTERVAL 7 DAY) <= DATE(createtime)";
//        $statisticsData = Yii::$app->db->createCommand($statisticsSql)
//            ->query();
//        array_push($result,$statisticsData);

        return $this->render('index', [
            'statisticsData' => $statisticsData,
            'statisticsDayData' => $statisticsDayData,

        ]);
    }

}
