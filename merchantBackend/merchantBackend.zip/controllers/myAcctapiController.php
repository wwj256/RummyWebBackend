<?php

namespace merchantBackend\controllers;

use common\models\Acctapi;

class myAcctapiController extends \yii\web\Controller
{
    public function actionIndex()
    {
        $model =  Acctapi::find()->select('nickname')->where('uid='.$id)->one();
        return $this->render('index', $model);
    }

    /**
     * Displays a single Acctapi model.
     * @param integer $id
     * @return mixed
     * @throws NotFoundHttpException if the model cannot be found
     */
    public function actionView($id)
    {
        return $this->render('view', [
            'model' => $this->findModel($id),
        ]);
    }

}
