<?php

namespace merchantBackend\controllers;

class ApidocController extends \yii\web\Controller
{

    public function actionIndex()
    {
        return $this->render('index');
    }
    public function actionStartpayment()
    {
        return $this->render('startpayment');
    }
    public function actionNotify()
    {
        return $this->render('notify');
    }
    public function actionOrderquery()
    {
        return $this->render('orderquery');
    }
    public function actionSign()
    {
        return $this->render('sign');
    }
    public function actionDemo()
    {
        return $this->render('demo');
    }
}
